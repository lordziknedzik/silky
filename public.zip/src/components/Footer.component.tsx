import React, {FunctionComponent} from 'react'

const Footer:FunctionComponent = () => {

    return (
        <footer className=''>
Footer
        </footer>
    )
}

export default Footer;