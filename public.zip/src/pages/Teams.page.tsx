import React, {FunctionComponent} from 'react'

const Teams:FunctionComponent = () => {

    return (
        <div className=''>
Teams
        </div>
    )
}

export default Teams;