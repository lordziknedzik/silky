import React, {FunctionComponent} from 'react'

const Contact:FunctionComponent = () => {

    return (
        <div className=''>
Contact
        </div>
    )
}

export default Contact;