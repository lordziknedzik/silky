import React, {FunctionComponent} from 'react'

const About:FunctionComponent = () => {

    return (
        <div className=''>
About
        </div>
    )
}

export default About;