import React, {FunctionComponent} from 'react'

const Join:FunctionComponent = () => {

    return (
        <div className=''>
Join
        </div>
    )
}

export default Join;