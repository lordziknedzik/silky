import React, {FunctionComponent} from 'react'

const Projects:FunctionComponent = () => {

    return (
        <div className=''>
Projects
        </div>
    )
}

export default Projects;